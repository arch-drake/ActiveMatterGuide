ACTIVE MATTER SOURCE ATLAS v2.2.0-alpha.1 — MAPS-ONLY PREVIEW

EXTRACT THIS ZIP COMPLETELY. Open index.html in Chrome or Edge.
The first card launches 13 source-derived overhead raster reference areas.
Gigastructure is separate: upload a floor image yourself; no fake flat map.
The online map tile host is contacted ONLY when you choose Load overhead map.
These are source tile windows, not certified exact raid boundaries.
No old unaligned pins are drawn over the primary source raster.
The separate 2.1.1 offline PvE/PvP companion is NOT included in this maps-only ZIP.
See the online project repository for the legacy guide and full source branch ZIP.

Feedback: https://github.com/arch-drake/ActiveMatterGuide/issues
This is a community alpha, not an officially supported game tool.
