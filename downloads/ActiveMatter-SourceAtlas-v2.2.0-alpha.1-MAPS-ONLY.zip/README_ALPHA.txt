ACTIVE MATTER SOURCE ATLAS v2.2.0-alpha.1 — MAPS-ONLY PREVIEW

Extract this entire ZIP to a folder. Open index.html using Chrome or Edge.
Click Launch maps for the primary source-raster atlas.
Live community-hosted tiles are downloaded only on explicit opt-in.
This is NOT certified exact raid geography. Historical pins remain unverified.
Gigastructure has no verified flat map. Import only your own floor reference.
This ZIP does NOT include the full 2.1.1 legacy offline PvE/PvP companion.
Get that legacy guide via its link from the launcher or download the full
repository candidate branch at:
https://github.com/arch-drake/ActiveMatterGuide/archive/refs/heads/alpha/v2.2.0-alpha.1.zip
Feedback: https://github.com/arch-drake/ActiveMatterGuide/issues
