# All-map production register — source-to-release
Last checked: 2026-10-20 · Accurate basemaps: **0 of 14 verified** · Current-screenshot-authenticated markers: **0 of 275**.
**Legend:** CANDIDATE = historic percent-coordinate source sample; CONCEPT = illustration with no comparable coordinate dataset. These are **not counts of all game POIs**.

| # | Map | Legacy sample markers | Basemap | Priority | Patch/variant risk | NEXT required artifact |
|---:|---|---:|---|---|---|---|
| 1 | Airport | 22 | Illustration | **P0 benchmark** | stationary exits relocated 0.4.0.173; gravity / vertical overlap | same-build map + 4 FIT / 2 CHECK |
| 2 | Headquarters | 21 | Illustration | P0 | exits relocated 0.4.0.173 | same-build Africa map + landmark set |
| 3 | Downtown | 29 | Illustration | P0 | exits relocated 0.4.0.173; Collapse variant | same-build city screenshot + variant mask |
| 4 | Dam | 21 | Illustration | P1 | water ladders / gravity stair fixed | current top-down dam and bridge/catwalk evidence |
| 5 | Cargo Port | 29 | Illustration | P1 | barge portals/teleport zones, 0.4.0.192 | current dock layout and source citation |
| 6 | Factory | 27 | Illustration | P1 | factory boundaries and fences patch-sensitive | building footprints with access tiers |
| 7 | Dogorsk | 25 | Illustration | P1 | dynamic exits; 0.4.0.192 scenery fix | screenshot + dynamic exit behavior |
| 8 | Military Base | 20 | Illustration | P1 | Unstable monster-artifact marker timing 0.4.0.192 | current PvE/Open/Unstable reference |
| 9 | Ozernoe | 20 | Illustration | P2 | green fences updated 0.4.0.192 | settlement geometry from real map |
| 10 | Park | 22 | Illustration | P2 | greenhouse / subterranean links | surface and underground level split |
| 11 | Scrapyard | 13 | Illustration | P2 | overlapping container/hangar interiors | exact hangar / junkyard footprints |
| 12 | Shegolskoe | 26 | Illustration | P2 | elevations and route cutoffs | current town geometry / route geometry |
| 13 | Gigastructure | 0 | Concept schematic | P3 | multi-floor traversal; no compatible coordinates | authenticated floor plans, one per level |
| 14 | Dalniy Island | 0 | Regional concept | P3 | region overview is not an individual raid | authenticated region outline; local raids separate |
| | **TOTAL** | **275** | | | | |

## Production checklist — repeat for every row
- [ ] Assign `map_id`, build, release mode, timestamp, coordinate system and orientation.
- [ ] Inventory potential source images; credit author and keep explicit publication rights record.
- [ ] Verify source is actual game overhead map, not another guide's imaginative redraw.
- [ ] Record screenshot dimensions + crop/orientation + SHA256.
- [ ] Identify stable fit landmarks; keep separate independent check points.
- [ ] Record geometry calibration metrics and disagreement reasons.
- [ ] Trace visible physical geometry; flag occlusion and unknown footprints.
- [ ] Evaluate legacy candidate pins one by one, in relevant variants.
- [ ] Audit changed extraction positions after official patch, record source version.
- [ ] Produce accurate **flat** reference layer first. Enhanced styling cannot shift measured geometry.
- [ ] Use height/volume only after oblique/measurement evidence; unknown remains 2D.
- [ ] QA markers, icons, legends, pan/zoom/rotation, local notes, dark-theme contrast, backup.
- [ ] Add per-map screenshots of test output and reviewer name/date.
- [ ] Update manifest/status from candidate to checked only after evidence signoff.

## Art and release separation
The offline visual addon contains category-level cinematic concept scenes for entries and location selector. It is **not** a geographic basemap replacement. Retain concept art as labelled editorial side panels and avoid letting it obstruct navigational icons.

## Updating status
Create a map correction issue with source build + raid variant and link to exported evidence JSON. Do not attach browser backup or authentication credentials. Update this table and audit manifest only when supporting proof is recorded. See [contributing](../CONTRIBUTING.md) and [fidelity standards](MAP_FIDELITY_EVIDENCE.md).

References: https://activematter.game/en/news/349 · https://activematter.game/en/news/356

## Real map-source tiles discovered on October 20
A tile-based actual-looking overhead Forsaken Africa basemap is visible at [Active Matter Help's Airport page](https://activematterhelp.ru/wiki/maps/africa_airport). This is **a verified location of third-party hosted raster source material**, not verification that the images are licensed for redistributing in our guide or that the coordinate samples align. See [tile discovery and coordinate blockers](AUTHENTIC_MAP_TILE_SOURCE_DISCOVERY.md). Airport and HQ should be first to obtain exact source extents; other region tile sets can be investigated after.

## Online cross-correlation (20 October 2026)

[All map/variant source links and patch audit](ONLINE_MAP_CORRELATION_2026_10_20.md) now covers the 13 reference game-map regions and 30 named raid variants. The 14th guide view is the Dalniy Island **regional** overview. Airport and Headquarters should be assigned to the **Africa** geographic region; they must not inherit the Dalniy coordinate grid. Source-reported extraction-system totals are variant-specific and cannot be treated as all simultaneously available exits. Military Base: Unstable Zone randomly uses one of 40 possible final extraction positions. Unchanged legacy coordinate samples: 275.

## Coordinate-georeferencing advance

A [source-derived world-coordinate crosswalk](GAME_WORLD_COORDINATE_CROSSWALK.md) now covers all 12 guide maps that have historic marker samples. **201 of the 275 source markers were directly crossmatched** to the third-party site's game-world X/Z data; the remaining 74 were not. Per-map horizontal affine checks were done with withheld imported source records. This is an aid to georeferencing current map screenshots, **not** an approved replacement for a verified game basemap or proof of current exit positions. No height layers were inferred from source `Y` elevations.

## Additional first-party Steam developer evidence — Park underground

The Steam discussion [“Park” (23–24 August 2026)](https://steamcommunity.com/app/2887580/discussions/0/591813437999457670/) contains a reply from developer-tagged **[CM] MajorMcDonalds** confirming that maps exist **inside the underground laboratory and near its entrance**, and advising players to use a flashlight/headlamp/NVG to find them. This supports an additional **Park / underground** floor-plan capture requirement, not the invention of an overhead bunker layout. The caveat is that this was an August response; check the current game build before using it as final artwork.

Player-executable evidence request: capture a clear image of those actual in-game underground floor maps plus the in-game map screen, ideally with door/ladder alignment landmarks, floor identifier and current patch number. The existing one-plane Park visual is **not** enough to faithfully render lower laboratory routing.

## Source-hosted visual tiles — all-map delivery 20 October

The standalone [Reference Atlas](../tools/map_reference_atlas.html) supports an opt-in external live tile view for **13/14 guide views**, covering Dalniy Island's 9 named local raids, its regional overview, Airport and Headquarters in Africa and Downtown in America. All images load directly from credited Active Matter Help's existing raster server. The tool uses verified source tile samples but a **four-by-four neighboring tile region is only an overview**, not a checked gameplay raid crop. Gigastructure remains a multi-floor exception with no verified overhead tiles. Source artwork is not repackaged, and the 275 historic guide markers are suppressed in remote source mode until independent source-pyramid georeferencing exists.

The earlier "0/14 game-exact maps" status is still valid for **independently authenticated raid geography/POIs**; the 13 live tile mosaic *visual reference modes* must not be misreported as 13 calibrated raid basemaps.
